# Imports
import glob
import numpy as np
from pytrf import date, sinex
from pytrf.ts import ts, model
from pytrf.io import read_solns



# Read master discontinuity list & PSD models
solns = read_solns('gen/soln_IGS20.snx')
psd = sinex.read('gen/psd_IGS20.snx')

# Loop over station position time series
files = np.sort(glob.glob('crd/*'))
for f in files:
    sta = f[4:8]
    print('Modeling position time series of station '+sta+'...')

    # Read time series
    r = ts.read(f, format=('t', 'x', 'y', 'z', 'qx', 'qxy', 'qxz', 'qy', 'qyz', 'qz'), dtrd=1, rotate=True)
    
    # Create & fit model
    m = model.from_solns(r, solns, code=sta, per=[365.25,182.625], noise=['vw'], psd=psd, fix_amp=True, fix_tau=True)
    m.fit_iter(thr_norm=5, quiet=True)
    m.fit_iter(thr_norm=5, thr_mad=5, win_mad=365, quiet=True)
    m.plot_fit(tunit='y', output='fig/'+sta+'-fit.png')
    m.plot_res(tunit='y', output='fig/'+sta+'-res.png')

    # Update list of outliers
    for i in range(len(r.tdel)):
        t = date.from_mjd(r.tdel[i])
        with open('del/{0.week}{0.dow}.del'.format(t), 'a') as fdel:
            print(sta, file=fdel)
