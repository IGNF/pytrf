# Imports
import os, glob
import numpy as np
from pytrf import date, sinex
from pytrf.io import read_solns
from pytrf.math import invspd



# Read master discontinuity list & PSD models
solns = read_solns('gen/soln_IGS20.snx')
psd = sinex.read('gen/psd_IGS20.snx')

# Loop over input SINEX files
files = np.sort(glob.glob('inputs/*'))
for f in files:
    print('Pre-processing '+f+'...')
    snx = sinex.read(f)

    # Check solution numbers
    snx.check_solns(solns, quiet=True)

    # Delete parameters that shouldn't be stacked
    snx.del_params(['ERP', 'GC'], keep_const=True)

    # Delete previously identified station position outliers
    t = date.from_tsnx(snx.param[0].tref)
    if (os.path.isfile('del/{0.week}{0.dow}.del'.format(t))):
        stadel = np.loadtxt('del/{0.week}{0.dow}.del'.format(t), dtype='O', ndmin=1)
        snx.del_sta(stadel, keep_const=True)

    # Remove PSD models
    snx.add_psd(psd, remove=True, update_cov=False)

    # Invert covariance matrix to save time during stacking
    snx.N = invspd(snx.Q)
    snx.Nc = None

    # Dump pre-processed sinex object (in a pickle file!)
    snx.dump('pkl/{0.week}{0.dow}.pkl'.format(t))
