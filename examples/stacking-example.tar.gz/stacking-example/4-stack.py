# Imports
from pytrf import date, sinex
from pytrf.io import read_solns
from pytrf.utils import record
from pytrf.snxcmb import combine



# Read master discontinuity list & PSD models
solns = read_solns('gen/soln_IGS20.snx')
psd = sinex.read('gen/psd_IGS20.snx')

# Prepare reference frame
tref = date.from_ymdhms(2018, 7, 1).tsnx()
ref = sinex.read('gen/IGS20.ssc', dont_read=['comments', 'metadata'])
ref.trim_solns(tref, solns)
ref.propagate(tref, keep_vel=True)

# Prepare list of inputs
inputs = []
for w in range(1930, 2086):
    for d in range(7):
        r = record()
        r.name = str(w)+str(d)
        r.file = 'pkl/'+r.name+'.pkl'
        r.description = 'IGS repro3 daily combined solution'
        r.params = 'RST'
        inputs.append(r)

# Call snxcmb.combine()
combsnx = combine(inputs, tref, solns=solns, check_solns=False, set_vel=True, dv_sig=1e-6, datum=ref, mc_sta='RST', mc_sta_sig=1e-5, mc_vel='RST', mc_vel_sig=1e-6,
                  norm_res='approx', vce='approx', store_inputs=False, reduce_trans=True, clear_neq=False)

# Iterative comparison with reference frame
combsnx.compare_iter(ref, 'RST', weighting='identity', thr_raw=4, clean_ref=True)

# Final inversion with NNRST constraints applied wrt clean reference frame
combsnx.clear_const()
combsnx.add_mc('RST', 'STA', sigma=1e-5, datum=ref)
combsnx.add_mc('RST', 'VEL', sigma=1e-6, datum=ref)
combsnx.add_dvc(solns, sigma=1e-6)
combsnx.neqinv()

# Check station metadata in long-term stacked solution
# combsnx.check_metadata(...)

# Write long-term stacked solution
print('Writing long-term stacked solution...')
combsnx.write('IGS-stacking.snx')

# Print combination residuals
print('Printing residuals...')
for inp in inputs:
    snx = sinex.load(inp.file, load_mat=False)
    
    for i in snx.ix:
        sta = snx.param[i].code
        t = date.from_tsnx(snx.param[i].tref).mjd
        v = inp.v[i:i+3]
        sv = inp.sv[i:i+3]
        
        f = open('res/'+sta+'.res', 'a')
        print('{0:7.1f}   {1[0]:9.3f} {1[1]:9.3f} {1[2]:9.3f}   {2[0]:9.3f} {2[1]:9.3f} {2[2]:9.3f}'.format(t, v, sv), file=f)
        f.close()
