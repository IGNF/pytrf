# Imports
import glob
import numpy as np
from pytrf import date, sinex



# Loop over input SINEX files
files = np.sort(glob.glob('inputs/*'))
for f in files:
    print('Extracting station positions from '+f+'...')
    snx = sinex.read(f)
    
    # Loop over station positions in input SINEX file
    for i in snx.ix:
        t = date.from_tsnx(snx.param[i].tref).mjd
        sta = snx.param[i].code
        X = snx.x[i:i+3]
        Q = snx.Q[i:i+3,i:i+3]
        
        # Update position time series of current station
        f = open('crd/'+sta+'.crd', 'a')
        print('{0:7.1f} {1[0]:21.14e} {1[1]:21.14e} {1[2]:21.14e} {2[0][0]:21.14e} {2[0][1]:21.14e} {2[0][2]:21.14e} {2[1][1]:21.14e} {2[1][2]:21.14e} {2[2][2]:21.14e}'.format(t, X, Q), file=f)
        f.close()
