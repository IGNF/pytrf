# Imports
import os
import numpy as np
from pytrf import date, sinex



# Download general files needed for the stacking example
os.system('wget -P gen ftp://igs-rf.ign.fr/pub/DOMES/codomes_gps_coord.snx') # Domes number catalogue
os.system('wget -P gen ftp://igs-rf.ign.fr/pub/IGS20/IGS20.ssc')             # IGS20 SINEX file (w/o covariance matrix)
os.system('wget -P gen ftp://igs-rf.ign.fr/pub/IGS20/soln_IGS20.snx')        # IGS20 discontinuity list
os.system('wget -P gen ftp://igs-rf.ign.fr/pub/IGS20/psd_IGS20.snx')         # IGS20 post-seismic deformation models

# List of stations that will be considerd in the stacking example.
# (For the stacking example to run quickly, let's consider only a small number of stations.)
sta = np.loadtxt('gen/station-list.txt', dtype='O')

# Loop over GPS weeks and days
# (This stacking example is limited to a 3-year period from week 1930 to week 2085.)
for w in range(1930, 2086):
    for d in range(7):
        t = date.from_wd(w, d+0.5)                                           # pytrf date object
        f = 'IGS1R03SNX_{0.yyyy}{0.doy}0000_01D_01D_SOL.SNX'.format(t)       # IGS repro3 SINEX solution of the day

        # Download IGS repro3 SINEX solution of the day
        os.system('wget -P inputs ftp://igs-rf.ign.fr/pub/repro3/{0.week}/{1}.gz'.format(t, f))

        # For the stacking example to run quickly, let's extract only a small number of stations from the whole solution.
        snx = sinex.read('inputs/'+f+'.gz')
        snx.keep_sta(sta)
        snx.write('inputs/'+f)

        # Remove original gzipped SINEX file
        os.system('rm inputs/'+f+'.gz')

