# Imports
import numpy as np
from pytrf import date, sinex
from pytrf.io import read_domes, read_solns, read_yaml
from pytrf.snxcmb import combine_iter



# Date of the combination
w = 2124    # GPS week
d = 0       # Day of week
t = date.from_wd(w, d+0.5)

# Start, middle and end of the day in SINEX date format
tstart = date.from_wd(w, d).tsnx()
tmid = t.tsnx()
tend = date.from_wd(w, d+1).tsnx()

# Read DOMES number catalogue
domes = read_domes('gen/codomes_gps_coord.snx')



# Prepare reference frame
#------------------------

# Read list of discontinuities that comes with the reference frame
solns = read_solns('gen/soln_IGS20.snx')

# Read post-seismic deformation models that come with the reference frame
psd = sinex.read('gen/psd_IGS20.snx')

# Read reference frame into a sinex object, omitting blocks that are not needed in order to gain speed
ref = sinex.read('gen/IGS20.ssc', dont_read=['comments', 'metadata'])

# Remove from reference frame 'solns' that are not relevant at date t
ref.trim_solns(tmid, solns)

# Compute positions at date t from positions at t0 + velocities
ref.propagate(tmid)

# Add post-seismic deformation models
ref.add_psd(psd)



# Prepare inputs of the combination
#----------------------------------

# Read list of inputs
inputs = read_yaml('inputs.yml', sed=True, t=t)

# Loop over inputs
for ac in inputs:
    print('Pre-processing {0}...'.format(ac.file))
    
    # Open log file
    log = open('log/prep-{0}.log'.format(ac.name), 'w')
    
    # Read SINEX file
    ac.snx = sinex.read(ac.file, dont_read=['comments'])
    
    # Check DOMES numbers and solns
    ac.snx.check_staid(domes, out=log)
    ac.snx.check_solns(solns, out=log)
    
    # Check parameter reference epochs & SOLUTION/EPOCHS block
    ac.snx.check_epochs(tstart, tend, tmid)
    
    # If needed, recover unconstrained normal equation. Else, just clear constraints.
    if (ac.snx.N is None):
        ac.snx.unconstrain()
    else:
        ac.snx.clear_const()
        
    # Fix some parameters to their a priori values
    ac.snx.fix_params(['UT', 'SATA', 'GC'])
    
    # Remove (eliminate) reference frame information from normal equation
    if (ac.del_rot):
        ac.snx.del_helmerts('RST', 'STA')
    else:
        ac.snx.del_helmerts('ST', 'STA')
    
    # First inversion with NNRST constraints wrt to reference frame
    ac.snx.add_mc('RST', 'STA', sigma='auto', datum=ref, thr=2)
    ac.snx.neqinv(clear_neq=False)
    
    # Iterative comparison between AC solution and reference frame
    refc = ref.copy()
    ac.snx.compare_iter(refc, 'RST', weighting='identity', norm_res='approx', thr_raw=3, clean_ref=True, out=log)

    # Final inversion with NNRST constraints wrt clean reference frame
    ac.snx.clear_const()
    ac.snx.add_mc('RST', 'STA', sigma='auto', datum=refc, thr=2)
    ac.snx.neqinv(clear_neq=False)
    
    # Assign a priori scaling factor
    senh = ac.snx.get_sigenh()
    s3d = np.sqrt(np.sum(senh**2, axis=1))
    ac.sf = 0.004 / np.median(s3d)
    
    # Close log file
    log.close()
    
    

# Combination
#------------

# Open log file
log = open('log/combination.log', 'w')

# Iterative combination
print('Iterative combination...')
combsnx = combine_iter(inputs, tmid, solns=solns, check_solns=False, datum=ref, mc_sta='RST', mc_sta_sig=1e-5, mc_sta_thr=2,
                       norm_res='approx', update_sf=True, thr_norm=5, flag_once=True, clear_neq=False, out=log)

# Post-process combined solution
print('Post-process combined solution...')
combsnx.del_params(['TRANS'])
combsnx.compare_iter(ref, 'RST', weighting='identity', norm_res='approx', thr_raw=3, clean_ref=True, out=log)
combsnx.clear_const()
combsnx.add_mc('RST', 'STA', sigma=1e-5, datum=ref, thr=2)
combsnx.neqinv()

# Check station metadata in combined solution
# combsnx.check_metadata(...)

# Write combined solution
print('Write combined solution...')
combsnx.write('ig3{0:04d}{1}.snx'.format(w, d), dont_write=['metadata'])
    
# Close log file
log.close()



# Draw maps of combination residuals
#-----------------------------------

print('Draw maps of combination residuals...')

for ac in inputs:
    ac.snx.map_res(ac.v, title='"{0} - igs" residuals'.format(ac.name), output='maps/{0}.png'.format(ac.name))
    
    
    
# Print combination residuals & statistics
#-----------------------------------------

# To do.
