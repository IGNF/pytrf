# Imports
import os
from pytrf import date
from pytrf.io import read_yaml



# Download general files needed for the combination example
os.system('wget -P gen ftp://igs-rf.ign.fr/pub/DOMES/codomes_gps_coord.snx') # Domes number catalogue
os.system('wget -P gen ftp://igs-rf.ign.fr/pub/IGS20/IGS20.ssc')             # IGS20 SINEX file (w/o covariance matrix)
os.system('wget -P gen ftp://igs-rf.ign.fr/pub/IGS20/soln_IGS20.snx')        # IGS20 discontinuity list
os.system('wget -P gen ftp://igs-rf.ign.fr/pub/IGS20/psd_IGS20.snx')         # IGS20 post-seismic deformation models

# Download input SINEX files of the combination example
# Note: To be able to get files from CDDIS, you need a ~/.netrc file as explained here:
# https://cddis.nasa.gov/Data_and_Derived_Products/CreateNetrcFile.html
w = 2124                                                                     # GPS week
d = 0                                                                        # Day of week
t = date.from_wd(w, d+0.5)                                                   # pytrf date object
inputs = read_yaml('inputs.yml', sed=True, t=t)                              # List of combination inputs

for ac in inputs:
    f = os.path.basename(ac.file)
    os.system('wget --auth-no-challenge -P inputs https://cddis.nasa.gov/archive/gnss/products/{0:04d}/repro3/{1}'.format(w, f))
