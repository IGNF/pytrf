# Imports
import numpy as np
import matplotlib.pyplot as pp
from pytrf import date, sinex
from pytrf.ts import ts, model
from pytrf.io import read_solns



# Read time series
r = ts.read('CKSV_igs.xyz', usecols=(2, 4, 5, 6, 7, 8, 9, 10, 11, 12), format=('t', 'x', 'y', 'z', 'sx', 'sy', 'sz', 'cxy', 'cxz', 'cyz'), dtrd=1, rotate=True)

# Remove points with unusually large formal errors
r.clean_sigmas()

# Plot time series
r.plot(tunit='y')



# Initialize model from:
# - discontinuity list (soln_IGS20.snx)
# - PSD SINEX file (psd_IGS20.snx)
# The deterministic model includes:
# - a piecewise linear part (as specified in soln_IGS20.snx)
# - exp and log functions (as specified in psd_IGS20.snx)
# - annual and semi-annual sine waves (as specified by the argument per).
# For now, the stochastic model includes only variable white noise.
solns = read_solns('soln_IGS20.snx')
psd = sinex.read('psd_IGS20.snx')
m = model.from_solns(r, solns, code='CKSV', per=[365.25, 182.625], noise=['vw'], psd=psd)

# Fit model and plot results (just to check that the deterministic model is appropriate)
m.fit()
m.plot_all(tunit='y')

# Iteratively fit model and remove outliers
m.fit_iter(thr_norm=5)
m.fit_iter(thr_norm=5, thr_mad=5, win_mad=365)

# Plot results again
m.plot_all(tunit='y')




# Add some more periodic terms & power-law noise to stochastic model
for T in [351.5, 351.5/2, 351.5/3, 351.5/4, 351.5/5, 351.5/6, 351.5/7, 351.5/8, 14.76, 14.19, 13.62]:
    m.add_sine(T)
m.add_pl()

# Fit model, print and plot results
m.fit(estimator='reml', method='Newton')
print(m)
m.plot_all(tunit='y')

# Dump model for future use
m.clean()
m.dump('CKSV.pkl')



# Load model
m = model.load('CKSV.pkl')
r = m.r
t = [date.from_mjd(d).ydec() for d in r.t]

# Plot Up component of time series + deterministic model
pp.figure(figsize=(8, 8), tight_layout=True)
pp.errorbar(t, r[2].y, yerr=np.sqrt(r[2].Q), fmt='.k', ecolor='gray', zorder=3, label='full time series')
pp.plot(t, m[2].yc, 'r', linewidth=2, zorder=4, label='deterministic model')
pp.fill_between(t, m[2].yc-m[2].sc, m[2].yc+m[2].sc, color='r', alpha=0.6, zorder=4)

# Plot filtered white noise & filtered power-law noise
pp.errorbar(t, m[2].n[0].xi-0.04, yerr=m[2].n[0].sxi, fmt='.c', ecolor='paleturquoise', zorder=3, label='filtered white noise')
pp.errorbar(t, m[2].n[1].xi-0.06, yerr=m[2].n[1].sxi, fmt='.', mfc='deeppink', mec='deeppink', ecolor='pink', zorder=3, label='filtered power-law noise')

# Finalize and show plot
pp.axis([2012, 2021, -0.07, 0.04])
pp.grid()
pp.xlabel('time [y]')
pp.ylabel('Up [m]')
pp.legend(framealpha=1)
pp.show()
