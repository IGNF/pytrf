# Imports
import numpy as np
import matplotlib.pyplot as pp
from scipy import signal
from scipy.stats import chi2
from pytrf import date
from pytrf.ts import ts, model, sine
from pytrf.math import lombscargle



# Gaussian window (later used to smooth periodograms on plots)
w = signal.windows.gaussian(7, 1)
w = w / np.sum(w)

# Read time series
r = ts.read('G055.zpco', usecols=(0, 2, 4), format=('t', 'x', 'qx'), dims=('z-PCO'))
t = [date.from_mjd(d).ydec() for d in r.t]

# Define & fit initial model
m = model(r, deg=[0, 1], noise=['vw', 'fn'])
m.add_jumps(deg=[0, 1], t=[57892])
m.fit(estimator='reml', method='BFGS')



# Iteratively refine model
iteration = -1
Tmax = np.inf
while (Tmax > 1e6):
    iteration += 1

    # Likelihood ratio tests for outliers, mean changes, trend changes, mean+trend changes, and sine waves.
    # The test results are transformed into "1 / odds" for illustration purposes.
    To = 1 / chi2.sf(m.glr_outlier(), 1)
    Tm = 1 / chi2.sf(m.glr_mean(), 1)
    Tt = 1 / chi2.sf(m.glr_trend(), 1)
    Tb = 1 / chi2.sf(m.glr_mean_trend(), 2)
    Ts = 1 / chi2.sf(m.glr_sine(), 2)

    # Initialize figure
    pp.figure(figsize=(20, 10), tight_layout=True)

    # Plot time series and deterministic model
    pp.subplot(321)
    for tc in m.f[0].t + m.f[1].t:
        yc = date.from_mjd(tc).ydec()
        pp.plot([yc, yc], [0.3, 0.6], '--r', linewidth=2, zorder=2)
    pp.errorbar(t, m.r.y, yerr=np.sqrt(m.r.Q), fmt='.k', ecolor='gray', zorder=3, label='time series')
    pp.plot(t, m.yc, 'r', linewidth=2, zorder=4, label='deterministic model')
    pp.fill_between(t, m.yc-m.sc, m.yc+m.sc, color='r', alpha=0.6, zorder=4)
    pp.axis([t[0], t[-1], 0.3, 0.6])
    pp.grid()
    pp.ylabel('z-PCO [m]')
    pp.legend(loc='upper left')

    # Plot residuals
    pp.subplot(323)
    pp.errorbar(t, m.v, yerr=m.sv, fmt='.k', ecolor='gray', zorder=3, label='residuals')
    pp.axis([t[0], t[-1], -0.15, 0.15])
    pp.grid()
    pp.ylabel('z-PCO residuals [m]')
    pp.legend(loc='upper right')

    # Plot results of likelihood ratio tests for mean changes, trend changes and mean+trend changes
    pp.subplot(325)
    pp.semilogy(t, To, 'k', label='outlier test')
    pp.semilogy(t, Tm, color='cornflowerblue', label='mean change test')
    pp.semilogy(t, Tt, color='green', label='trend change test')
    pp.semilogy(t, Tb, color='darkturquoise', label='mean+trend change test')
    pp.axis([t[0], t[-1], 1, 1e7])
    pp.grid()
    pp.xlabel('time [yr]')
    pp.ylabel('1 / (1 - CDF)')
    pp.legend(loc='upper right')

    # Plot periodogram of full time series + frequencies of sine waves included in current model
    pp.subplot(322)
    for f in m.f:
        if isinstance(f, sine):
            pp.plot([365.25/f.per, 365.25/f.per], [1e-5, 1], '--r', linewidth=2, zorder=2)
    (f, p) = lombscargle(m.r.t, m.r.y)
    pp.loglog(365.25*m.fr, signal.convolve(p, w, mode='same'), 'k', zorder=3, label='periodogram of full time series')
    pp.axis([0.1, 182.625, 1e-5, 1])
    pp.grid()
    pp.ylabel('power spectral density [m²/cpy]')
    pp.legend(loc='upper right')
    
    # Plot periodogram of residuals and power spectrum of noise model
    pp.subplot(324)
    pp.loglog(365.25*m.fr, signal.convolve(m.pv, w, mode='same'), 'k', zorder=3, label='periodogram of residuals')
    pp.loglog(365.25*m.fr, m.pn, 'r', linewidth=2, zorder=4, label='PSD of noise model')
    pp.fill_between(365.25*m.fr, m.pn-m.spn, m.pn+m.spn, color='r', alpha=0.6, zorder=4)
    pp.axis([0.1, 182.625, 1e-5, 1])
    pp.grid()
    pp.ylabel('power spectral density [m²/cpy]')
    pp.legend(loc='upper right')

    # Plot results of likelihood ratio tests for sine waves
    pp.subplot(326)
    pp.loglog(365.25*m.fr, Ts, color='purple', label='sine wave test')
    pp.axis([0.1, 182.625, 1, 1e7])
    pp.grid()
    pp.xlabel('frequency [cpy]')
    pp.ylabel('1 / (1 - CDF)')
    pp.legend(loc='upper left')

    # Save figure
    pp.savefig('iter'+str(iteration))

    
    
    # Maximal test result
    Tmax = np.max([np.max(To), np.max(Tm), np.max(Tt), np.max(Tb), np.max(Ts)])
    
    # If maximal test results corresponds to an outlier, remove it.
    if (Tmax == np.max(To)):
        i = np.argmax(To)
        m.del_points([i])

    # If maximal test results corresponds to a mean change, add it to the model.
    elif (Tmax == np.max(Tm)):
        i = np.argmax(Tm)
        m.add_jumps(deg=[0], t=[m.r.t[i]])
        
    # If maximal test results corresponds to a trend change, add it to the model.
    elif (Tmax == np.max(Tt)):
        i = np.argmax(Tt)
        m.add_jumps(deg=[1], t=[m.r.t[i]])
        
    # If maximal test results corresponds to a mean+trend change, add it to the model.
    elif (Tmax == np.max(Tb)):
        i = np.argmax(Tb)
        m.add_jumps(deg=[0, 1], t=[m.r.t[i]])
    
    # If maximal test results corresponds to a sine wave, add it to the model.
    else:
        i = np.argmax(Ts)
        m.add_sine(per=1/m.fr[i])
        
        
        
    # Fit updated model
    m.fit(estimator='reml', method='BFGS')
