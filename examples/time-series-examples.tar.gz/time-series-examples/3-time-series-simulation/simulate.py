# Imports
from pytrf.ts import ts, model
import matplotlib.pyplot as pp



# Initialize empty time series
r = ts(1000, dims=('Up'))

# Initialize model with a linear component and one mean change
m = model(r, deg=[0, 1])
m.add_jumps(t=[600], deg=[0])
m.f[0].par[0].x = -1
m.f[0].par[1].x = 3
m.f[1].par[0].x = 0.005

# Add white noise + flicker noise
m.add_wn(s2=1)
m.add_pl(s2=1, a=1)

# Simulate & plot time series
m.simulate()
r.plot()

# Plot covariance matrix
pp.pcolormesh(m.Q, cmap='inferno')
pp.colorbar()
pp.show()



# Fit model, print and plot results
m.fit()
print(m)
m.plot_fit(show=False)
m.plot_psd()
